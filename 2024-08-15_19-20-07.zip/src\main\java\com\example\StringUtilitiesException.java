package com.example;

public class StringUtilitiesException extends RuntimeException {
    public StringUtilitiesException(String message) {
        super(message);
    }
}
