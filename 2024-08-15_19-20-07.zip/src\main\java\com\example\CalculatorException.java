package com.example;

public class CalculatorException extends RuntimeException {
    public CalculatorException(String message) {
        super(message);
    }
}
